package com.storageflyesp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Switch fly = findViewById(R.id.flySwitch);
        Switch esp = findViewById(R.id.espSwitch);

        fly.setOnCheckedChangeListener((button, checked) ->
            Toast.makeText(this, "Fly: " + (checked ? "ON" : "OFF"), Toast.LENGTH_SHORT).show()
        );

        esp.setOnCheckedChangeListener((button, checked) ->
            Toast.makeText(this, "Storage ESP: " + (checked ? "ON" : "OFF"), Toast.LENGTH_SHORT).show()
        );
    }
}
