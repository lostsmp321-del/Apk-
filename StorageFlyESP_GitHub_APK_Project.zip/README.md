# Storage Fly ESP Android Project

GitHub Actions builds a debug APK automatically.

## GitHub steps
1. Create a new GitHub repository.
2. Upload all files from this project.
3. Commit to the `main` branch.
4. Open the **Actions** tab.
5. Select **Build APK**.
6. Run the workflow with **Run workflow** if it has not run automatically.
7. Open the completed workflow.
8. Download the **StorageFlyESP-debug** artifact.
9. Extract the ZIP and install the APK on Android.

Important: This APK is a user interface/control app. It does not inject into or modify Minecraft. For Minecraft Bedrock, use the add-on in a world/server where you have permission.
